package com.exemple.fretestrategy.sprint2atv1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Sprint2Atv1ApplicationTests {

    @Test
    void contextLoads() {
    }

}
