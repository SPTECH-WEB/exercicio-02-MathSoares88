package com.exemple.fretestrategy.sprint2atv1;

public interface Observer {
    void notificar(String mensagem);
}