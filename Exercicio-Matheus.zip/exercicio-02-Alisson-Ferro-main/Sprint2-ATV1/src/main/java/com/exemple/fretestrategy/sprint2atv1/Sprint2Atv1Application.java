package com.exemple.fretestrategy.sprint2atv1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Sprint2Atv1Application {

    public static void main(String[] args) {
        SpringApplication.run(Sprint2Atv1Application.class, args);
    }

}
