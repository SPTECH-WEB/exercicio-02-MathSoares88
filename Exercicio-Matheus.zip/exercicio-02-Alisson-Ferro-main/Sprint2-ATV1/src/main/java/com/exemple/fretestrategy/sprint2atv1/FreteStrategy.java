package com.exemple.fretestrategy.sprint2atv1;

public interface FreteStrategy {
    double calcularFrete(double peso);
}