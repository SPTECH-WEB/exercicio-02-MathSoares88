package com.exemple.fretestrategy.sprint2atv1;

public class FreteRequest {
    private double peso;
    private String modalidade;

    // Getters e Setters
    public double getPeso() {
        return peso;
    }

    public void setPeso(double peso) {
        this.peso = peso;
    }

    public String getModalidade() {
        return modalidade;
    }

    public void setModalidade(String modalidade) {
        this.modalidade = modalidade;
    }
}