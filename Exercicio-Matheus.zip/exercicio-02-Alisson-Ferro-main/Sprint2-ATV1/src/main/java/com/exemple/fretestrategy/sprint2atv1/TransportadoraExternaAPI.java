package com.exemple.fretestrategy.sprint2atv1;

public class TransportadoraExternaAPI {
    public double calcularCusto(double peso) {
        return peso * 7.5; // Regra da transportadora externa
    }
}